// Preload SpeechSynthesis to avoid initial delay
window.speechSynthesis.onvoiceschanged = () => {
  const preloadUtterance = new SpeechSynthesisUtterance(" ");
  window.speechSynthesis.speak(preloadUtterance);
  window.speechSynthesis.cancel();
};

// Get references to DOM elements
const selectedTextArea = document.getElementById("selectedText");
const languageSelect = document.getElementById("language");
const translateButton = document.getElementById("translate");
const speakButton = document.getElementById("speak");
const translationOutput = document.getElementById("translation");

// Function to fetch selected text
function fetchSelectedText() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript(
      {
        target: { tabId: tabs[0].id },
        func: () => {
          const selectedText = window.getSelection().toString();
          const pdfViewer =
            document.querySelector("embed[src$='.pdf']") ||
            document.querySelector("iframe[src$='.pdf']") ||
            document.querySelector("embed[type='application/pdf']") ||
            document.querySelector("iframe[type='application/pdf']");

          if (pdfViewer) {
            if (!selectedText) {
              return {
                type: "pdf",
                message: "PDF detected, but no text is selected.",
              };
            }
            return { type: "text", text: selectedText };
          }

          return { type: "text", text: selectedText || "" };
        },
      },
      (results) => {
        if (results && results[0] && results[0].result) {
          const result = results[0].result;

          if (result.type === "pdf" && result.message) {
            alert(
              "Text selection from PDFs is not supported directly. Please copy the text from the PDF manually and paste it into the textarea."
            );
            selectedTextArea.value = ""; // Clear the textarea
          } else if (result.type === "text" && result.text.trim()) {
            selectedTextArea.value = result.text; // Set the selected text
          } else {
            selectedTextArea.value = ""; // Clear the textarea if no text is selected
          }
        }
      }
    );
  });
}

// Fetch selected text on popup load
fetchSelectedText();

// Translate text
translateButton.addEventListener("click", async () => {
  const text = selectedTextArea.value.trim();
  const targetLang = languageSelect.value;

  if (!text) {
    alert("Please select or enter text to translate.");
    return;
  }

  try {
    const res = await fetch(
      `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(
        text
      )}`
    );
    const data = await res.json();
    const translatedText = data[0].map((segment) => segment[0]).join(" ");
    translationOutput.textContent = translatedText;

    // Adjust translation output box size dynamically
    translationOutput.style.height = "auto";
    translationOutput.style.height = `${translationOutput.scrollHeight}px`;
  } catch (error) {
    alert("Translation failed. Please try again.");
    console.error(error);
  }
});

// Speak the selected or translated text
speakButton.addEventListener("click", () => {
  const textToSpeak =
    translationOutput.textContent.trim() || selectedTextArea.value.trim();

  if (textToSpeak) {
    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.lang = languageSelect.value;

    // Cancel any ongoing speech and start speaking
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  } else {
    alert("No text available to speak. Please translate or select text.");
  }
});
