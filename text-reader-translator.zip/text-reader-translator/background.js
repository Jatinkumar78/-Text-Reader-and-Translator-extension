// background.js
chrome.runtime.onInstalled.addListener(() => {
  console.log("Text Reader and Translator extension installed.");
});
